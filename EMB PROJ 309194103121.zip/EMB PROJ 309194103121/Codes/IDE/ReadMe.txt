If you cannot access the file in the zip, copy paste the code from Embedde.txt 


Libraries used are in folder Libs

Change the ssid and password in code.

_____________________________________________________________________________

  BT21ECE030     BT21ECE091     BT21ECE094     BT21ECE103      BT21ECE121
_____________________________________________________________________________