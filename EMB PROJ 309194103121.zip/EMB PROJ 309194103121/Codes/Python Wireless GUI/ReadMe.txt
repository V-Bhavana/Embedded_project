
We used Kivy , os , requests , time Libraries 
kivy is used for GUI
os , requests and time are used for Response handling.

Change the localIP of your computer code url="https://192.168.x.xx"
_____________________________________________________________________________

  BT21ECE030     BT21ECE091     BT21ECE094     BT21ECE103      BT21ECE121
_____________________________________________________________________________