SETUP

We used female headers and connected modules so that we can change it if anything short cirucits.
Also we have future scope for this project so
we made it removable/reusable

OUTPUT image

in our output when the connection is reset that value is going back to 0 so we can see some irregularities in output.
which can be fixed by small modification. which we cannot accomplish due to time constraint.

_____________________________________________________________________________

  BT21ECE030     BT21ECE091     BT21ECE094     BT21ECE103      BT21ECE121
_____________________________________________________________________________