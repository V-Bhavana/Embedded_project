Folders with respect to items are added

PCB gerber file can be opened by any gerber file viewer

it is generated using EASYEDA

Datasheets are data of stored people

extra functionality is added LOGIN PAGE

IDE code possibly might not open due to security issues
 
Use the .txt file and copy paste it in IDE.

BOM has bills of each component.

_____________________________________________________________________________

  BT21ECE030     BT21ECE091     BT21ECE094     BT21ECE103      BT21ECE121
_____________________________________________________________________________